#!/bin/sh
set -eu
if [ "$(id -u)" = 0 ]; then
    echo 'Run as a normal, non-root Linux user (permission tests require it).' >&2
    exit 1
fi
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
work=$(mktemp -d)
trap 'chmod -R u+rwX "$work" 2>/dev/null || :; rm -rf "$work"' EXIT
ulimit -c 0
cxx=${CXX:-g++}
# Test-only GNU linker hooks selectively simulate I/O faults and pathname races.
# Use SANITIZE=1 to enable ASan/UBSan in addition to libstdc++ assertions.
flags='-std=c++98 -Wall -Wextra -Werror -pedantic -D_GLIBCXX_ASSERTIONS'
if [ "${SANITIZE:-0}" = 1 ]; then flags="$flags -g -fsanitize=address,undefined -fno-omit-frame-pointer"; fi
"$cxx" $flags "$src/Execution.cpp" "$src/test.cpp" -Wl,--wrap=open,--wrap=close,--wrap=write,--wrap=readdir,--wrap=remove -o "$work/audit"
cd "$work"
if [ "${1:-}" = '--invalid-config' ]; then
    ./audit empty-location
else
    ./audit
fi
