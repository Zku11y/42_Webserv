Webserv pre-CGI resource-handler audit (Linux)

Execution.cpp: source from the uploaded Pasted markdown.md, Markdown formatting
removed, include replaced by stub.hpp. No functional changes.
stub.hpp: minimal stand-in structures and declarations, plus a generic
ft_to_string. These are NOT the real project headers. In particular, parser,
response serialization, network handling, maximum body size, and CGI execution
are not implemented in this harness.
test.cpp: direct calls to the resource handlers using already-parsed requests.
Test-only functions are not restricted by the 42 project system-call list.
run.sh: compile the isolated harness and use a fresh private temporary directory.
results-final.txt: actual output of the final ASan/UBSan run as nobody on Linux.
sanitizer-final.txt: sanitizer stderr from that run (empty on success).
invalid-config.txt: intentional libstdc++ assertion failure for empty location.

Run, as a non-root user on Linux with g++ and GNU linker:
    ./run.sh
    SANITIZE=1 ./run.sh
    ./run.sh --invalid-config    # expected abort; tests missing config guard

PASS verifies expected current behavior, even if that behavior is a limitation.
REPRO demonstrates a diagnostic condition, not necessarily a defect under the
agreed configuration assumptions. The suite intentionally asserts known current
behavior, so fixing a defect may turn a diagnostic into NOT REPRO and require
revising its assertion. The synthetic fault hooks force deterministic operations
at specific boundaries. They do not imply a remote-only exploit.

The source and harness are for audit/reproduction, not a submission or a full
server integration test. No network listener or CGI process is launched.
