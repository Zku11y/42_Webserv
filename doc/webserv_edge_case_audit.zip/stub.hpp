#ifndef WS_STUB_HPP
#define WS_STUB_HPP
#include <string>
#include <vector>
#include <map>
#include <sstream>
#include <iostream>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
struct HttpRequest { int localPort; std::string localHost,host,port,method,target,path,queryString,version,body; std::map<std::string,std::string> headers; int bodyFd; size_t b_size; HttpRequest():localPort(8080),localHost("127.0.0.1"),method("GET"),bodyFd(-1),b_size(0){} };
struct Response { int status_code; std::map<std::string,std::string> headers; std::string body; int body_fd; size_t body_size; Response():status_code(0),body_fd(-1),body_size(0){} };
struct Client { HttpRequest parsed_req; Response rsp; };
struct LocationConfig {std::string _path,_root,_index,_uploadStore,_returnTarget; std::vector<std::string> _methods; bool _autoindex,_uploadEnable; int _returnCode; std::map<std::string,std::string> _cgi; LocationConfig():_autoindex(false),_uploadEnable(false),_returnCode(0){} };
struct ServerConfig {int _port; std::string _host; std::vector<LocationConfig> _locations; std::map<int,std::string> _errorPages; ServerConfig():_port(8080),_host("127.0.0.1"){} };
struct Config {std::vector<ServerConfig> _servers;};
template<class T> std::string ft_to_string(T v){ std::ostringstream s;s<<v;return s.str(); }
class Execution { public:
 int status; HttpRequest req; bool cgi_exc; std::string cgi_path, full_path; ServerConfig s_conf; LocationConfig s_location;
 Execution(Client&); int ft_select_server(Config&); int ft_validate_path(); int ft_select_location(); int ft_validate_methods(); std::string ft_resolve_full_path_2(); void ft_resolve_full_path_1(); void ft_init_cgi_var(); int ft_handle_path(std::string,int,struct stat&,int&); void ft_handle_resource(Client&,Config&); void ft_handle_G_autoindex(Client&); void ft_handle_G_files(Client&,struct stat&,int&); void ft_handle_G_dir(Client&,int&); void ft_handle_Get(Client&); void ft_handle_Post(Client&); void ft_handle_Delete(Client&); int ft_error_1(Client&); void ft_error_2(Client&); void ft_handle_error(Client&,int); void ft_handle_error_2(Client&,int); void ft_handle_Redirect_2(Client&); void ft_handle_Redirect(Client&); void ft_handle_cgi(); std::vector<std::string> ft_split(const std::string&,char) const; std::string ft_trim(const std::string&); std::string ft_to_lower(const std::string&) const; std::string ft_mime_types();
};
#endif
